// Analizador léxico
