// Analizador sintáctico
